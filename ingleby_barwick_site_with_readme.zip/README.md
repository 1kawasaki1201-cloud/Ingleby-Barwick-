# Ingleby Barwick — A Short History Website

This repository contains a simple, static website presenting a short history of **Ingleby Barwick**, from prehistoric archaeology to its modern development as a town.

## 🚀 How to View Locally
1. Download or clone this repository.
2. Open `index.html` in your web browser.

## 🌐 Deploy to GitHub Pages
You can easily publish this website online using GitHub Pages:

1. Create a GitHub repository (e.g., `ingleby-barwick-history`).
2. Upload the contents of this project (`index.html`, `styles.css`, `script.js`).
3. Commit the changes.
4. Go to **Settings → Pages**.
5. Under **Branch**, select:
   - Branch: `main` (or `master`)
   - Folder: `/ (root)`
6. Click **Save**.

Your site will be available at:

```
https://YOUR-USERNAME.github.io/ingleby-barwick-history/
```

## 📂 Project Structure
- `index.html` — main webpage
- `styles.css` — styling
- `script.js` — small JavaScript (menu toggle, footer year, etc.)
- `README.md` — instructions

## 📜 License
This project is provided for educational and community use.
