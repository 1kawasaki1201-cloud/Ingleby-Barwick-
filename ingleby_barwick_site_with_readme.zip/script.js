document.addEventListener('DOMContentLoaded',()=>{
  const y = new Date().getFullYear();
  document.getElementById('year').textContent = y;
  const btn = document.getElementById('menuToggle');
  if(btn){btn.addEventListener('click',()=>{
    const nav=document.getElementById('navList');
    if(nav.style.display==='flex'){nav.style.display='none';}
    else{nav.style.display='flex';}
  });}
});